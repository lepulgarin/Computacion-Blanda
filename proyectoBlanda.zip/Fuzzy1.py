import numpy as np
import skfuzzy as fuzz
import matplotlib.pyplot as plt

def fuzzy(c_,d_):
    # Generate universe variables
    #   * Quality and service on subjective ranges [0, 10]
    #   * Tip has a range of [0, 25] in units of percentage points
    estado_carretera = np.arange(0, 11, 1)
    dia = np.arange(0, 7, 1)
    peligro  = np.arange(0, 101, 1)

    # Generate fuzzy membership functions
    estado_carretera_bajo = fuzz.trimf(estado_carretera, [0, 0, 5])
    estado_carretera_medio = fuzz.trimf(estado_carretera, [0, 5, 10])
    estado_carretera_alto = fuzz.trimf(estado_carretera, [5, 10, 10])
    dia_bajo = fuzz.trimf(dia, [0, 0, 4])
    dia_medio = fuzz.trimf(dia, [0, 4, 6])
    dia_alto = fuzz.trimf(dia, [4, 6, 6])
    peligro_bajo = fuzz.trimf(peligro, [0, 0, 50])
    peligro_medio = fuzz.trimf(peligro, [0, 50, 100])
    peligro_alto = fuzz.trimf(peligro, [50, 100, 100])

    # We need the activation of our fuzzy membership functions at these values.
    # The exact values 8 and 6 do not exist on our universes...
    # This is what fuzz.interp_membership exists for!
    nivel_estado_carretera_bajo = fuzz.interp_membership(estado_carretera, estado_carretera_bajo, c_)
    nivel_estado_carretera_medio = fuzz.interp_membership(estado_carretera, estado_carretera_medio, c_)
    nivel_estado_carretera_alto = fuzz.interp_membership(estado_carretera, estado_carretera_alto, c_)

    nivel_dia_bajo = fuzz.interp_membership(dia, dia_bajo, d_)
    nivel_dia_medio = fuzz.interp_membership(dia, dia_medio, d_)
    nivel_dia_alto = fuzz.interp_membership(dia, dia_alto, d_)

    # Now we take our rules and apply them. Rule 1 concerns bad food OR service.
    # The OR operator means we take the maximum of these two.
    active_rule1 = np.fmax(nivel_estado_carretera_bajo, nivel_dia_bajo)

    # Now we apply this by clipping the top off the corresponding output
    # membership function with `np.fmin`
    activacion_peligro_bajo = np.fmin(active_rule1, peligro_bajo)  # removed entirely to 0

    # For rule 2 we connect acceptable service to medium peligro_totalping
    activacion_peligro_medio = np.fmin(nivel_dia_medio, peligro_medio)

    # For rule 3 we con nect high service OR high food with high tipping
    active_rule3 = np.fmax(nivel_estado_carretera_alto, nivel_dia_alto)
    activacion_peligro_alto = np.fmin(active_rule3, peligro_alto)
    tip0 = np.zeros_like(peligro)

    # Aggregate all three   output membership functions together
    aggregated = np.fmax(activacion_peligro_bajo,
                         np.fmax(activacion_peligro_medio, activacion_peligro_alto))

    # Calculate defuzzified result
    peligro_total = fuzz.defuzz(peligro, aggregated, 'centroid')
    activacion_peligro = fuzz.interp_membership(peligro, aggregated, peligro_total)  # for plot

    return peligro_total
