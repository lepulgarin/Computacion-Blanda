from pyDatalog import pyDatalog
import math
from Backpropagation import *
from Fuzzy1 import *

pyDatalog.create_terms('Velocidad, V, Accidentalidad, Velocidad_limite')

def experto(acc_):

    print(acc_)

    Accidentalidad=round(acc_)
    #base de conocimiento
    +Velocidad(0,"70-90")
    +Velocidad(1,"50-70")
    +Velocidad(2,"30-50")
    +Velocidad(3,"10-30")

    V(Accidentalidad,Velocidad_limite) <= Velocidad(Accidentalidad, Velocidad_limite)
    print(V(Accidentalidad,Velocidad_limite))



def main():
    #[clima,riesgo,mes],[accidentalidad]
    display=[
        [[0,0.25,0.03],[0.3]],
        [[0.40,0.75,0.07],[0.5]],
        [[0.80,0.80,0.11],[0.7]],
        [[0.20,0.30,0.12],[0.5]],
        [[1.0,1.0,0.12],[0.9]],
        [[0,0,0.04],[0.0]],
        [[0.20,0.20,0.05],[0.2]],
        [[0.40,0.30,0.07],[0.7]],
        [[0.90,0.90,0.10],[1.0]],
        [[0.35,0.15,0.01],[0.1]]]

    red = RedNeuronal(3,3,1)
    red.Entrenamiento(display)
    red.Resultado(display)

    dia = input("ingrese dia [0-6]: ")
    estado_carretera = input("ingrese estado carretera [0 - 10]: ")
    mes = input("ingrese mes [1-12]: ")
    clima = input("ingrese nivel de lluvia [0 - 100]: ")
    riesgo = fuzzy(estado_carretera,dia)
    riesgo = riesgo/100
    n = [
        [[(float(clima)/100),(float(riesgo)),(float(mes)/100)],[0.0]]
    ]
    accidentalidad = red.Resultado(n)
    accidentalidad = float(accidentalidad[0])*3.2
    experto(int(accidentalidad))
main()
